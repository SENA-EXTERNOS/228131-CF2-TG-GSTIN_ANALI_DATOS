function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MYNLrlWYi9":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

