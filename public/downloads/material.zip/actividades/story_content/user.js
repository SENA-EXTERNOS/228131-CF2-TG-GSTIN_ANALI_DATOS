function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6JzCavy0jp3":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

