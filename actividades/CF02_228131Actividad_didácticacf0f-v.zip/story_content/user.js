function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5d5LBMiQ1mv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

